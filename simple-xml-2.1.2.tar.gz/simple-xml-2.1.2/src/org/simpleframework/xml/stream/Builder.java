/*
 * Builder.java July 2008
 *
 * Copyright (C) 2008, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package org.simpleframework.xml.stream;

import java.util.concurrent.ConcurrentHashMap;

/**
 * The <code>Builder</code> class is used to represent an XML style
 * that can be applied to a serialized object. A style can be used to
 * modify the element and attribute names for the generated document.
 * Styles can be used to generate hyphenated or camel case XML.
 * <pre>
 * 
 *    &lt;example-element&gt;
 *        &lt;child-element example-attribute='example'&gt;
 *           &lt;inner-element&gt;example&lt;/inner-element&gt;
 *        &lt;/child-element&gt;
 *     &lt;/example-element&gt;
 *     
 * </pre>
 * Above the hyphenated XML elements and attributes can be generated
 * from a style implementation. Styles enable the same objects to be
 * serialized in different ways, generating different styles of XML
 * without having to modify the class schema for that object.    
 * 
 * @author Niall Gallagher
 */
class Builder implements Style {
   
   /**
    * This is the cache for the constructed attribute values.
    */
   private final Cache attributes;
   
   /**
    * This is the cache for the constructed element values. 
    */
   private final Cache elements;
   
   /**
    * This is the style object used to create the values used.
    */
   private final Style style;
   
   /**
    * Constructor for the <code>Builder</code> object. This will cache
    * values constructed from the inner style object, which allows the
    * results from the style to retrieved quickly the second time.
    * 
    * @param style this is the internal style object to be used
    */
   public Builder(Style style) {
      this.attributes = new Cache();
      this.elements = new Cache();
      this.style = style;
   }

   /**
    * This is used to generate the XML attribute representation of 
    * the specified name. Attribute names should ensure to keep the
    * uniqueness of the name such that two different names will
    * be styled in to two different strings.
    * 
    * @param name this is the attribute name that is to be styled
    * 
    * @return this returns the styled name of the XML attribute
    */
   public String getAttribute(String name) {
      String value = attributes.get(name);
      
      if(value != null) {
         return value;
      }
      value = style.getAttribute(name);
      
      if(value != null) {
         attributes.put(name, value);
      }
      return value;
   }

   /**
    * This is used to generate the XML element representation of 
    * the specified name. Element names should ensure to keep the
    * uniqueness of the name such that two different names will
    * be styled in to two different strings.
    * 
    * @param name this is the element name that is to be styled
    * 
    * @return this returns the styled name of the XML element
    */
   public String getElement(String name) {
      String value = elements.get(name);
      
      if(value != null) {
         return value;
      }
      value = style.getElement(name);
      
      if(value != null) {
         elements.put(name, value);
      }
      return value;
   }

   /**
    * This is used to set the attribute values within this builder.
    * Overriding the attribute values ensures that the default
    * algorithm does not need to determine each of the values. It
    * allows special behaviour that the user may require for XML.
    * 
    * @param name the name of the XML attribute to be overridden
    * @param value the value that is to be used for that attribute
    */
   public void setAttribute(String name, String value) {
      attributes.put(name, value);
   }

   /**
    * This is used to set the element values within this builder.
    * Overriding the element values ensures that the default
    * algorithm does not need to determine each of the values. It
    * allows special behaviour that the user may require for XML.
    * 
    * @param name the name of the XML element to be overridden
    * @param value the value that is to be used for that element
    */
   public void setElement(String name, String value) {
      elements.put(name, value);   
   }

   /**
    * The <code>Cache</code> object is used to cache the values 
    * used to represent the styled attributes and elements. This 
    * is a concurrent hash map so that styles can be used by more
    * than one thread simultaneously.
    * 
    * @author Niall Gallagher
    */
   private class Cache extends ConcurrentHashMap<String, String> {
    
      /**
       * Constructor for the <code>Cache</code> object. This will
       * create a concurrent cache that can translate between the
       * XML attributes and elements and the styled values.
       */
      public Cache() {
         super();
      }
   }
}